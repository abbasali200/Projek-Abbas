package com.example.mengirimdatapadaintent

class Companion {

}
